import os
print("Содержимое папки: " + str(os.listdir()))