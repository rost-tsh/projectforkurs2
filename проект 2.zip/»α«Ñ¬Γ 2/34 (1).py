import pickle
import random
random.seed()
n = random.randint(3, 10)
F = open('data.pkl','wb')

S=set()

for i in range(n):
    S.add(random.randint(-32768, 32767))
pickle.dump(S,F)
F.close()

F = open('data.pkl','rb')

S = pickle.load(F)

print(S,type(S))
F.close()
