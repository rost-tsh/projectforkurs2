f = open('8-sr2.txt')
a = f.readline().split()
i = 0
while int(a[i]) % 10 != 3 and i<len(a)-1:
    i = i + 1
print(int(a[i])%10 == 3)
