import random
random.seed()
f = open('myfile.txt', 'wb')
kol_number = random.randint(10,15)
for i in range(kol_number):
    number = random.randint(1,32767)
    number_str =number.to_bytes(2, byteorder='little',signed=True)
    f.write(number_str)
f.close()
