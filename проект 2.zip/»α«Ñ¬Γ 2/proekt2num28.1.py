# создаем файл со случайными числами
import random
random.seed()
n = random.randint(3, 10)

# Создаем/открываем битовый файл "numbers1.dat" для записи:
f = open("numbers1.dat", "wb")
for i in range(n):
    # Будем использовать формат числа 2 байта со знаком,
    # Максимально допустимый диапазон:[-32768, 32767].
    x= random.randint(-32768, 32767)
    # Перевод в bytes:
    bx = x.to_bytes(2, byteorder='little',signed=True)
    # Сохранение 2 байт в файл:
    f.write(bx)
f.close( )

# считываем все числа и записываем в список
f = open("numbers1.dat", "rb")
# читаем из него по 2 байта:
bx= f.read(2)
L=[]
s=0
# Проверка на пустую строку bytes b'':
while bx!= b'':
    s+=1
    # Перевод из bytesв число int:
    x = int.from_bytes(bx, byteorder='big',signed=True)
    L.append(bx)
    # выводим числа на экран:
    print(x)# читаем из файла по 2 байта:
    bx = f.read(2)
f.close()

print(L)

# переворачиваем список
L.reverse()
print(L)
print(s)

#очищаем файл и записываем новые числа
f = open("numbers1.dat", "wb")
for i in range(s):
    bx=L[i]
    # Сохранение 2 байт в файл:
    f.write(bx)
f.close()

# проверяем перезаписался ли файл
f = open("numbers1.dat", "rb")
# читаем из него по 2 байта:
bx= f.read(2)

while bx!= b'':
    # Перевод из bytesв число int:
    x = int.from_bytes(bx, byteorder='big',signed=True)
    # выводим числа на экран:
    print(x)# читаем из файла по 2 байта:
    bx = f.read(2)
f.close()
