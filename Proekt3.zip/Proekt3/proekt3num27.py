import numpy as np
np.random.seed(100)
x = np.random.randint(-100, 101, size = (3,3))

print(x)
print(x.size)
print(x[x>0])
print(x[x>0].size)
if (x[x>0].size == x.size):
    print(True)
else:
    print(False)
