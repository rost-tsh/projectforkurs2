import numpy as np
np.random.seed(1000)
x = np.random.randint(-100, 101, size = (3,3))
print(x)
print()
w,v = np.linalg.eig(x)
print(w)
print()
print(v)
