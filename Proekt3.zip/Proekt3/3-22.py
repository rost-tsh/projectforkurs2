import numpy as np
a = np.random.randint(-10,10,10)
print(a)
a1 = np.sum(a)
print(a1)
a2 = np.mean(a)
print(a2)
a3 = np.min(a)
print(a3)
