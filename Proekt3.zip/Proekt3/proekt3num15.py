import numpy as np
np.random.seed(1000)
x = np.random.randint(-100, 101, 5)
y = np.random.randint(-100, 101, 5)
print(x)
print(y)
print(np.dot(x, y))
