import numpy as np
a = np.random.random(2)
print (a)
b = np.random.random(8)
print (b)