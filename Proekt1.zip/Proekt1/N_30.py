from tkinter import*
from math import *
from tkinter.messagebox import*

root = Tk()
root.title('Stolitz')


win2 = Frame(root,bg = 'purple')
win2.pack(anchor = 'n',expand = YES, fill = BOTH)
Label(win2, text = "F: ").pack(side = LEFT, padx = 10, pady = 10)
entF=Entry(win2)
entF.pack(side = LEFT,padx = 10, pady = 10, expand = YES, fill = X)
entF.insert(0, 'x+1')

Label(win2, text = "G: ").pack(side = LEFT, padx = 10, pady = 10)
entF1 = Entry(win2)
entF1.pack(side = LEFT, padx = 10, pady = 10, expand = YES, fill = X)
entF1.insert(0,'x * 2')
K = [1,0,0,0,0,0,0,0,0,0]

def action():
    F = entF.get()
    F1 = entF1.get()
    for x in range(0,9):
        s=eval(F)
        s1 = eval(F1)
        if (s<10):
            K[x + 1] += K[x]
        if (s1<10):
            K[2*(x+1)-1] += K[x]
    LabF['text'] = K

Button(win2, text = "Вычисление Функции F",command = action).pack(side = LEFT, padx = 10, pady = 4)
LabF = Label(win2, text = "")
LabF.pack(side = LEFT, padx = 10, pady = 10)



root.mainloop()
