from tkinter import*
from tkinter.messagebox import*
from math import*
root = Tk()
root.title("Решение квадратного уравнения")

root.minsize(width = 350, height = 150)
root.maxsize(width = 700, height = 700)

fr_1 = Frame(root, bg  =  'black' )

fr_1.pack(expand = YES, fill = BOTH)

vv = Label(fr_1, text = "Уравнение вида: ax^2 + bx + c = 0", bg  =  'black')
vv['fg'] = 'yellow'
vv.config(font = ('times',20,'bold'))
vv.pack(side = TOP, padx = 10, pady = 10)

la = Label(fr_1, text = "Введите a = ", bg = 'yellow')
lb = Label(fr_1, text = "Введите b = ", bg = 'yellow')
lc = Label(fr_1, text = "Введите c = ", bg = 'yellow')
la.pack(side = LEFT, padx = 10, pady = 10)
entA = Entry(fr_1, bg = 'yellow')
entA.insert(0, 0)
entA.pack(side = LEFT, padx = 10, pady = 10)
lb.pack(side = LEFT, padx = 10, pady = 10)
entB = Entry(fr_1, bg = 'yellow')
entB.insert(0, 0)
entB.pack(side = LEFT, padx = 10, pady = 10)
lc.pack(side = LEFT, padx = 10, pady = 10)
entC = Entry(fr_1, bg = 'yellow')
entC.insert(0, 0)
entC.pack(side = LEFT, padx = 10, pady = 10)
fr_res = Frame(root, bg  =  'black')
fr_res.pack(side = TOP, expand = YES, fill = BOTH)
def OnButton():
    try:
        a = float(entA.get())
    except ValueError:
        showerror("Ошибка заполнения", "Переменная a не является числом")
        return
    try:
        b = float(entB.get())
    except ValueError:
        showerror("Ошибкка заполнения", "Переменная b не является числом")
        return
    try:
        c = float(entC.get())
    except ValueError:
        showerror("Ошибка заполнения", "Переменная c не является числом")
        return
    if (a==b==c==0):
        Ires['text'] = "x принадлежит вещественной оси"
    elif b*b - 4 * a * c < 0:
        Ires['text'] = "корней нет"
    
    else:
        res1 = (-b + sqrt(b*b - 4 * a * c)) / 2 * a
        res2 = (-b - sqrt(b*b - 4 * a * c)) / 2 * a
        if res1 == res2:
            res1 = str(res1)
            res2 = str(res2)
            tres = "Один корень уравнения: " + res1
            Ires['text'] = tres
        else:
            res1 = str(res1)
            res2 = str(res2)
            tres = "Первый корень: " + res1 + "; Второй корень: " + res2
            Ires['text'] = tres
Button(fr_res, text = '=', width = 10, command = OnButton).pack(side = LEFT, padx = 30, pady = 20)
Ires = Label(fr_res, text = "", bg  =  'black', fg = 'yellow')
Ires.config(font = ('times',10,'bold'))
Ires.pack(side = LEFT, padx = 30, pady = 20)
root.mainloop()
