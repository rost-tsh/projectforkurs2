from  tkinter  import  *   	# подключаем  tkinter

# Подключаем  модуль с диалоговыми  окнами  tkinter:
from  tkinter.messagebox  import  * 

root  =  Tk( )    	# создаем главное окно

# Устанавливаем минимальные и максимальные размеры окна:
root.minsize(width = 350, height = 150)
root.maxsize(width = 500, height = 300)

root.title("Просто кнопка")         # заголовок окна

win1  =  Frame(root, bg = '#555555')

win1.pack(expand  =  YES, fill  =  BOTH)

def OnButtunResult():
   showerror("Стандартное диалоговое окно showerror")
   return

Button(win1, text = "showerror", command=OnButtunResult).pack(side = LEFT, 
              padx  =  120,  pady  =  10) 

# Запуск цикла обработки сообщений:
root.mainloop()
