from tkinter import *

# подключаем диалоговые окна:
from tkinter.messagebox import * 

#  подключаем диалоговое окно выбор цвета:
from tkinter.colorchooser import askcolor 
import random as rand

rand.seed()

root = Tk( )
root.title("Главное окно программы")

root.minsize(width = 350, height = 150)
root.maxsize(width = 500, height = 300)

#  Создаем фрейм для размещения на нем других компонент:
win1 = Frame(root, bg  =  '#555555')

win1.pack(anchor = "n", expand = YES, fill = X)
can  =  Canvas(root)
can.pack(expand  =  YES, fill  = BOTH)

var = IntVar()
var.set(2)

Radiobutton(win1,text="Width = 2", variable = var, value = 2).pack(side  =  LEFT,padx=5,
                              pady  =  10
)
Radiobutton(win1,text="Width = 3", variable = var, value = 3).pack(side  =  LEFT,padx=5,
                              pady  =  20
)
Radiobutton(win1,text="Width = 10", variable = var, value = 10).pack(side  =  LEFT,padx=5,
                              pady  =  30
)


#  Обработчик кнопки закрытия программы: 
def closeQuery():
    if  askyesno('Выход из программы...', 'Закрыть программу? '):
        showwarning('Диалоговое окно', 'Внимание!!!')
        root.destroy(  )
    else:
        showinfo('Диалоговое окно', 'Информация')


Button(win1, text  =  'Выход', command  =  closeQuery).pack(
    		  side  =  RIGHT, padx  =  10, pady  =  5)
# Создаем обработчик кнопки 'Рисовать': 
def  my_set_color():
   
    #   Запускаем диалоговое окно выбора цвета: 
    res  =  askcolor()
    
    
    
    #  Печатаем результат res, который вернул диалог: 
    print("Диалоговое окно Цвет возвращает результат:", res)
    if   res[1]:
        
        # если цвет был выбран, то
        
        can.create_oval(
            rand.uniform(40, 80), rand.uniform(10, 30), rand.uniform(100, 200), rand.uniform(40, 60), outline=res[1],
            fill=res[1], width= var.get()
        )
Button(win1, text  =  'Цвет', command  =  my_set_color).pack(
              side  =  RIGHT, padx  =  10, pady  =  5)

# Запуск цикла обработки сообщений:
root.mainloop()
